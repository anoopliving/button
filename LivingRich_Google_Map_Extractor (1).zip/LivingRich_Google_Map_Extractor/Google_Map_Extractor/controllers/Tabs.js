const Tabs = {
    list : [
        {id:'home',name : "Home"},
        {id:'notifications',name : "Notifications"},
    ],
};